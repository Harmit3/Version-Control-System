public class MathOps {

    public int square(int x) {
        return x * x;
    }

    public int cube(int x) {
        return x * x * x;
    }

    public static void main(String[] args) {
        MathOps m = new MathOps();
        System.out.println(m.square(4));
        System.out.println(m.cube(2));
        System.out.println(m.cube(3));
    }
}
